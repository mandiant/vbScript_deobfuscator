
todo: handle byref, byval, const private =


Vbscript deobsfuscator v 0.1d

Date: 3.11.16

really complex, but seems to be working quite well.
about 12hrs in now.

First click indent, then click rename

you can double click or hit space on names in the listviews
to rename them from the defaults.

if you do rename them manually, its up to you to make sure
you dont create conflicts. I am to lazy to add these checks
right now.

select an item in teh list and hit 'd' to keep its default name

bugs: ?? 

other credits: 
  CIndenter.cls from VBIDEUtils addin 
  Author: http://www.ppreview.net 
  Date: 1997


version:
 3.13 - rename 3x speed increase